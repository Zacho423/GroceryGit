Grocery Price Aggregator:
GitHub: https://github.com/Zacho423/GroceryGit
Step 1: Open command prompt and type: pip install streamlit pandas requests altair
Step 2: Once necessary packages have been installed, type: python -m streamlit run grocery_aggregator.py 
**Run this inside the folder that holds the file but cannot be in one drive**
Mock data mode will simulate stores and prices based on zip code.
**Kroger mode will require a client ID and secret.**
Client ID: grocerystorepriceaggregator-bbc9x9y2
Secret: PnARAo7ru9MEmIyaEPiSXs5wNCMo0G8j8APsQqgC

Kroger mode will show you Kroger stores in your area as well as prices for items based on the store. If an item does not display results, you may need to be more specific
(ex: "wheat bread" instead of just "bread").

This project was designed to impact the common good by providing an easy way to compare the cost of goods at stores in your area. Future improvements could involve the addition of a web scraper to get real prices from stores other than Kroger.